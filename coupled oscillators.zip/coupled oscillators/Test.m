k = load('Data.mat')';

